<?php
require_once 'connexion.php';
require_once 'Book.php';
class BookDAO{
    private $db;
    public function __construct(){
        $this->db = Database::getInstance()->getConnection(); 
    }

    public function get_books(){
            try {
                $query = "SELECT * FROM BOOK";
                $stmt = $this->db->prepare($query);
                $stmt->execute();
                $booksData = $stmt->fetchAll(PDO::FETCH_ASSOC); // Use FETCH_ASSOC for better clarity
        
                $books = [];
                foreach ($booksData as $data) {
                    $books[] = new Book($data['ISBN'], $data['Title'], $data['Genre'], $data['NumOfPages'], $data['Price'], $data['Author']);
                }
                return $books;
            } catch (PDOException $e) {
                echo "Error: " . $e->getMessage();
                return [];
            }
        }

    public function insertBook(Book $book) {
        try {
            $query = "INSERT INTO BOOK (ISBN, Title, Genre, NumOfPages, Price, Author) VALUES (:isbn, :title, :genre, :pages, :price, :author)";
            $stmt = $this->db->prepare($query);
            $isbn = $book->getISBN();
            $title = $book->getTitle();
            $genre = $book->getGenre();
            $pages = $book->getNumofPges();
            $price = $book->getPrice();
            $author = $book->getAuthor();
    
            $stmt->bindParam(':isbn', $isbn);
            $stmt->bindParam(':title', $title);
            $stmt->bindParam(':genre', $genre);
            $stmt->bindParam(':pages', $pages);
            $stmt->bindParam(':price', $price);
            $stmt->bindParam(':author', $author);
            return $stmt->execute(); 
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
            return false; 
        }
    }


}



?>