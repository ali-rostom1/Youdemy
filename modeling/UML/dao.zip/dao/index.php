<?php 
require_once 'BookDAO.php';
 $book = new BookDAO();
 $books = $book->get_books();

 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form action="AddBookController.php" method="post">
        <label>ISBN:</label>
        <input type="text" name="isbn" required><br>
        <label>Title:</label>
        <input type="text" name="title" required><br>
        <label>Genre:</label>
        <input type="text" name="genre" required><br>
        <label>Number of Pages:</label>
        <input type="number" name="pages" required><br>
        <label>Price:</label>
        <input type="number" step="0.01" name="price" required><br>
        <label>Author:</label>
        <input type="text" name="author" required><br>
        <button type="submit" name="submit">Add Book</button>
    </form>

    <h1>Liste des livres</h1>
    <table>
        <tr>
        <th>ISBN</th>
        <th>Titre</th>
        <th>Genra</th>
        <th>Price</th>
        <th>Number of pages</th>
        <th>Author</th>
        </tr>
        <?php
            foreach($books as $book1){
                echo "<tr> 
                    <td>".$book1->getISBN()."</td>
                    <td>".$book1->getTitle()."</td>
                    <td>".$book1->getGenre()."</td>
                    <td>".$book1->getNumofPges()."</td>
                    <td>".$book1->getPrice()."</td>
                    <td>".$book1->getAuthor()."</td>
                </tr>";
            }
        ?>
            <td></td>
    </table>
</body>
</html>
