<?php 
 
    class Book{
        private $ISBN;
        private $title;
        private $Genre;
        private $NumofPges;
        private $Price;
        private $Author;



        public function __construct($ISBN, $title, $Genre, $NumofPges , $Price, $Author){
            $this->ISBN = $ISBN;
            $this->title = $title;
            $this->Genre = $Genre;
            $this->NumofPges = $NumofPges;
            $this->Price = $Price;
            $this->Author = $Author;
        }

        /**
         * Get the value of ISBN
         */ 
        public function getISBN()
        {
                return $this->ISBN;
        }

        /**
         * Get the value of title
         */ 
        public function getTitle()
        {
                return $this->title;
        }

        /**
         * Get the value of Genre
         */ 
        public function getGenre()
        {
                return $this->Genre;
        }

        /**
         * Get the value of NumofPges
         */ 
        public function getNumofPges()
        {
                return $this->NumofPges;
        }

        /**
         * Get the value of Price
         */ 
        public function getPrice()
        {
                return $this->Price;
        }

        /**
         * Get the value of Author
         */ 
        public function getAuthor()
        {
                return $this->Author;
        }
    }
?>