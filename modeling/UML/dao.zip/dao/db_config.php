<?php

define('DB_HOST', 'localhost');

define('DB_NAME', 'BOOKAPP');

define('DB_USER', 'root');

define('DB_PASS', '');

?>