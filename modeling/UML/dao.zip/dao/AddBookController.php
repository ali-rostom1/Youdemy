<?php
require_once 'BookDAO.php';
$bookDAO = new BookDAO();
if (isset($_POST['submit'])) {
    $isbn = $_POST['isbn'];
    $title = $_POST['title'];
    $genre = $_POST['genre'];
    $pages = $_POST['pages'];
    $price = $_POST['price'];
    $author = $_POST['author'];

    $newBook = new Book($isbn, $title, $genre, $pages, $price, $author);


    if ($bookDAO->insertBook($newBook)) {
        echo "Book added successfully!";
    } else {
        echo "Failed to add book.";
    }
}?>